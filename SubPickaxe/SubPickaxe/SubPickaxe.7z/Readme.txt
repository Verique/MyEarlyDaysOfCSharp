Extract .exe file from SubPickaxe.7z

Drag & Drop .ass file onto .exe to SRficate it!

You can also just open .ass file with this .exe file