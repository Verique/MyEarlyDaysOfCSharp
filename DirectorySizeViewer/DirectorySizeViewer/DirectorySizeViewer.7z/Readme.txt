Extract .exe file from DirectorySizeViewer.7z

Run an .exe file in directory, where you want to know subdirectories sizes

Some system directories or protected ones can cause an error